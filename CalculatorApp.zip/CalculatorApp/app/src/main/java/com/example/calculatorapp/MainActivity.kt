package com.example.calculatorapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import kotlinx.android.synthetic.main.activity_main.*
import net.objecthunter.exp4j.ExpressionBuilder

class MainActivity : AppCompatActivity() {




     var userText =""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



    }




    fun numbers(view: android.view.View) {
       var userText=editText.text.toString()

        var userSelection= view as Button


        when(userSelection.id){
            num1.id -> {userText+="1"
            }
            num2.id -> {userText+="2"}
            num3.id -> {userText+="3"}
            num4.id -> {userText+="4"}
            num5.id -> {userText+="5"}
            num6.id -> {userText+="6"}
            num7.id -> {userText+="7"}
            num8.id -> {userText+="8"}
            num9.id -> {userText+="9"}


            del.id -> {
                if(userText.contains(".")){
                    userText +=""
                }else{
                userText +=".0"}}
            NegPos.id -> {
                if(userText.toDouble()>=0)
                userText="-$userText"
            }
            c.id -> {userText=""}

            point.id -> {userText+="."}
            zerp.id -> {userText+="0"}
        }
       // for(i in userText)
        editText.setText(userText)
    }

    fun operation(view: android.view.View) {

        var userSelection= view as Button
       var userText =editText.text.toString()
        when(userSelection.id) {
            sum.id -> {
                userText+="+"
            }
            multiply.id -> {
                userText+="*"
            }
            divid.id -> {
                userText+="/"
            }
            subtract.id -> {
                userText+="-"
            }

        }

            editText.setText(userText)

    }

    fun result(view: android.view.View) {

                val text = editText.text.toString()
                val expression = ExpressionBuilder(text).build()

                val result = expression.evaluate()
                val longResult = result.toLong()
                if (result == longResult.toDouble()) {

                    editText.setText(longResult.toString())
                } else {
                    editText.setText(result.toString())
                }




        }
    //}
}